<script setup>
import Navbar from './components/Navbar.vue'
import TaskList from './components/TaskList.vue';
</script>

<template>
  <header>
  </header>
  <Navbar/>
  <main>
    <div class="container">
      <TaskList />
    </div>
  </main>
</template>

<style scoped></style>
