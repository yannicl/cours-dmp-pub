<template>
    <select>
        <option value="recent">Tâches récentes (1)</option>
        <option value="archive">Tâches archivées (1)</option>
    </select>
    <button type="button" class="btn btn-link"><i class="bi bi-trash3"></i>Archiver les
        tâches terminées</button>
    <ul class="list-group">
        <li class="list-group-item">
        <i class="bi bi-star"></i>
        <span class="text-decoration-line-through">Terminer le laboratoire 1</span>
        <br/>
        <!--<button type="button" class="btn btn-link">
            <i class="bi bi-circle"></i>
            Réouvrir
        </button>-->
        <button type="button" class="btn btn-link">
            <i class="bi bi-check2-circle"></i>
            Fermer
        </button>
        <!--<button type="button" class="btn btn-link">
            <div>
                <i class="bi bi-caret-down"></i>
                Déprioriser
            </div>
        </button>-->
        <!--<button type="button" class="btn btn-link text-danger">
            <i class="bi bi-trash3"></i>
            Effacer
        </button>-->
    </li>
        
    </ul>
    <ul class="list-group">
    </ul>
    <form>
        <div class="mb-3 mt-2 row">
            <div class="col-sm-9 mt-1">
                <input class="form-control" type="text" placeholder="Nouvelle tâche">
            </div>
            <div class="col-sm-3 mt-1">
                <button type="button" class="btn btn-primary"><i class="bi bi-play"></i>Créer</button>
            </div>
        </div>
    </form>
</template>

<script>

</script>


<style scoped></style>