<script>


export default {
}
</script>

<template>
  <div>
    <h2>Détail du contact</h2>
  </div>
</template>

<style>
img {
  width: 100px;
}
</style>
