<script>
import { RouterLink } from 'vue-router';
export default {
  
}
</script>

<template>
    <h2>Tous les contacts</h2>
    <ul>
      <li v-for="contact in this.contacts">
        <RouterLink :to="{name: 'detail', params : {email : contact.email}}">{{contact.firstName}} {{ contact.lastName }}</RouterLink>
      </li>
    </ul>
</template>
