<script>
import { RouterLink } from 'vue-router';
export default {
  
}

</script>

<template>
    <h2>Recherche</h2>
    <form>
      <input type="text" placeholder="Search...">
    </form>
    <ul>
    </ul>
</template>
