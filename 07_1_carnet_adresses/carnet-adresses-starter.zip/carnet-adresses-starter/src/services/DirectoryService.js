export class DirectoryService {

    getAllContacts() {
        return this.persons;
    }

    getContactDetail(email) {
        return this.persons.find((person) => person.email == email);
    }


    persons = [
        {
            "firstName": "John",
            "lastName": "Doe",
            "email": "john.doe@example.com",
            "title" : "Art Director",
            "avatar" :  "/images/Multiavatar-01.png"
        },
        {
            "firstName": "Jane",
            "lastName": "Smith",
            "title" : "Audio Engineer",
            "email": "jane.smith@example.com",
            "avatar" :  "/images/Multiavatar-02.png"
        },
        {
            "firstName": "Michael",
            "lastName": "Johnson",
            "title" : "Event Coordinator",
            "email": "michael.johnson@example.com",
            "avatar" :  "/images/Multiavatar-03.png"
        },
        {
            "firstName": "Emily",
            "lastName": "Brown",
            "title" : "Music Producer",
            "email": "emily.brown@example.com",
            "avatar" :  "/images/Multiavatar-04.png"
        },
        {
            "firstName": "David",
            "lastName": "Taylor",
            "title" : "Production Assistant",
            "email": "david.taylor@example.com",
            "avatar" :  "/images/Multiavatar-05.png"
        },
        {
            "firstName": "Sarah",
            "lastName": "Miller",
            "title" : "Creative Director",
            "email": "sarah.miller@example.com",
            "avatar" :  "/images/Multiavatar-06.png"
        },
        {
            "firstName": "Daniel",
            "lastName": "Anderson",
            "title" : "Event Planner",
            "email": "daniel.anderson@example.com",
            "avatar" :  "/images/Multiavatar-07.png"
        },
        {
            "firstName": "Sophia",
            "lastName": "Thomas",
            "title" : "Video Editor",
            "email": "sophia.thomas@example.com",
            "avatar" :  "/images/Multiavatar-08.png"
        },
        {
            "firstName": "James",
            "lastName": "Wilson",
            "title" : "Finance Director",
            "email": "james.wilson@example.com",
            "avatar" :  "/images/Multiavatar-09.png"
        },
        {
            "firstName": "Oliver",
            "lastName": "Clark",
            "title" : "HR Coordinator",
            "email": "oliver.clark@example.com",
            "avatar" :  "/images/Multiavatar-10.png"
        }
    ];


}