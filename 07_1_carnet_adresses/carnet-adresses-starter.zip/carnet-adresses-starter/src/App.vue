<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <header>
    <div>
         <h1>Carnet d'adresse de Compagnie A</h1>
    </div>
    <nav>
      <ul>
        <li><RouterLink to="/">Liste</RouterLink></li>
        <li><RouterLink to="search">Recherche</RouterLink></li>
      </ul>
    </nav>
  </header>
  <main>
    <RouterView />
  </main>
</template>

<style scoped></style>
