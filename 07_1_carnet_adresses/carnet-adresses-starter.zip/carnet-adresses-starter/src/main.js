import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { DirectoryService } from './services/DirectoryService'

const app = createApp(App)

app.use(router)

// mecanisme inject/provide
app.provide('directoryService', new DirectoryService());

app.mount('#app')
