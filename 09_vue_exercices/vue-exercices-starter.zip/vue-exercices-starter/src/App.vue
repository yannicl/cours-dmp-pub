<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <header>
    <div class="sidenav">
      <nav>
        <RouterLink to="/ex1">Exercice 1</RouterLink>
        <RouterLink to="/ex2">Exercice 2</RouterLink>
        <RouterLink to="/ex3">Exercice 3</RouterLink>
        <RouterLink to="/ex4">Exercice 4</RouterLink>
        <RouterLink to="/ex5">Exercice 5</RouterLink>
        <RouterLink to="/ex6">Exercice 6</RouterLink>
        <RouterLink to="/ex7">Exercice 7</RouterLink>
        <RouterLink to="/ex8">Exercice 8</RouterLink>
        <RouterLink to="/ex9">Exercice 9</RouterLink>
      </nav>
    </div>
  </header>
  <div class="content">
    <RouterView />
  </div>
</template>

<style scoped>
a {
  display: block;
}
.sidenav {
  height: 100%; /* 100% Full-height */
  width: 20em; /* 0 width - change this with JavaScript */
  position: absolute; /* Stay in place */
  z-index: 1; /* Stay on top */
  top: 0; /* Stay at the top */
  left: 2em;
  overflow-x: hidden; /* Disable horizontal scroll */
  padding-top: 60px; /* Place content 60px from the top */
  border-right: solid 2px;
  border-color: black;
}

.content {
  height: 100%; /* 100% Full-height */
  width: 100% - 25em; /* 0 width - change this with JavaScript */
  position: absolute; /* Stay in place */
  z-index: 1; /* Stay on top */
  top: 0; /* Stay at the top */
  left: 25em;
  overflow-x: hidden; /* Disable horizontal scroll */
  padding-top: 60px; /* Place content 60px from the top */
}
</style>
