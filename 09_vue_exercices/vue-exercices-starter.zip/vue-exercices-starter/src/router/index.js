import { createRouter, createWebHistory } from 'vue-router'
import Ex1View from '../views/Ex1View.vue'
import Ex2View from '../views/Ex2View.vue'
import Ex3View from '../views/Ex3View.vue'
import Ex4View from '../views/Ex4View.vue'
import Ex5View from '../views/Ex5View.vue'
import Ex6View from '../views/Ex6View.vue'
import Ex7View from '../views/Ex7View.vue'
import Ex8View from '../views/Ex8View.vue'
import Ex9View from '../views/Ex9View.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/ex1',
      name: 'ex1',
      component: Ex1View,
    },
    {
      path: '/ex2',
      name: 'ex2',
      component: Ex2View,
    },
    {
      path: '/ex3',
      name: 'ex3',
      component: Ex3View,
    },
    {
      path: '/ex4',
      name: 'ex4',
      component: Ex4View,
    },
    {
      path: '/ex5',
      name: 'ex5',
      component: Ex5View,
    },
    {
      path: '/ex6',
      name: 'ex6',
      component: Ex6View,
    },
    {
      path: '/ex7',
      name: 'ex7',
      component: Ex7View,
    },
    {
      path: '/ex8',
      name: 'ex8',
      component: Ex8View,
    },
    {
      path: '/ex9',
      name: 'ex9',
      component: Ex9View,
    },
  ],
})

export default router
