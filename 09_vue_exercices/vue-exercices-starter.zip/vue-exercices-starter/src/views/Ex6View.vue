<template>
  <div>
    <h1>Exercice 6</h1>
    <p>Lorsque le bouton est cliqué, convertissez la température de degrés Celcius à degrés Fahrenheit.</p>
  </div>
  <input type="text"><span>&deg;C</span><br/>
  <button>Convertir en &deg;F</button><br/>
  <span>{{ degresF }}</span><span>&deg;F</span>
</template>

<script>
export default {
  
}
</script>

<style scoped>
</style>
