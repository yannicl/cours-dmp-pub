<template>
  <div>
    <h1>Exercice 4</h1>
    <p>Créer un composant qui affiche la date, inclure ce composant dans la page.</p>
  </div>
</template>

<script>
import DateComponent from '@/components/DateComponent.vue'
export default {

}
</script>

<style scoped>
</style>
