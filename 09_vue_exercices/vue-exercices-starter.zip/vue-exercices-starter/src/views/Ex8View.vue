<template>
  <div>
    <h1>Exercice 8</h1>
    <p>Créer un composant Article pour afficher chaque article de la liste.</p>
  </div>
  <div>
  </div>
  
</template>

<script>
const articles = [
  {titre: "HP OfficeJet 8015e", prixunitaire: 129.99},
 {titre: "HP Envy Inspire 7958e", prixunitaire: 285.00, description: "Imprimante tout-en-un, impression, copie, numérisation, impression mobile et sans fil, alimentation automatique de documents."},
 {titre: "Souris sans fil HP X3000", prixunitaire: 16.99}
];
import ArticleComponent from '@/components/ArticleComponent.vue';

export default {
}
</script>

<style scoped>
</style>
