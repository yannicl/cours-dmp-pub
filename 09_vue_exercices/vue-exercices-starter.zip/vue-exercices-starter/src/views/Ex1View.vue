<template>
  <div>
    <h1>Exercice 1</h1>
    <p>Afficher la liste des continents</p>
  </div>
  <div>
    <ul>
      <li>Asie</li>
    </ul>
  </div>
</template>

<script>
const continents = ["Asie", "Europe", "Afrique", "Amérique du Nord", "Amérique du Sud", "Antartique", "Océanie"]

export default {
  
}
</script>

<style>
</style>
