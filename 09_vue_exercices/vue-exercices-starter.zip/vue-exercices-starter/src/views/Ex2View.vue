<template>
  <div>
    <h1>Exercice 2</h1>
    <p>Afficher la population d'un continent. Le continent est sélectionné à l'aide du dropdown. 
      La population est retournée à l'aide d'une propriété calculée.</p>
  </div>
  <div>
    <span>La population de </span>
    <select>
      <option>Asie</option>
    </select>
  <span> est de 4 806 898 000</span>
  </div>
</template>

<script>
const continents = [
  {nom: "Asie", population: 4806898000},
  {nom: "Europe", population: 745084000}, 
  {nom: "Afrique", population: 1515141000},
  {nom: "Amérique du Nord", population: 385295000},
  {nom: "Amérique du Sud", population: 663466000},
  {nom: "Océanie", population: 46089000}
];

export default {
}
</script>

<style>
</style>
