<template>
  <div>
    <h1>Exercice 3</h1>
    <p>Masquer le texte d'aide lorsque le mot de passe a au moins 8 caractères et afficher le crochet vert.</p>
  </div>
  <div>
    <span>Choisissez un mot de passe </span>
    <input type="password"/>
    <span class="mdp_aide"> (Le mot de passe doit avoir au moins 8 caractères)</span>
    <span class="mdp_valid">&#x2713;</span>
  </div>
</template>

<script>

export default {
  
}
</script>

<style scoped>
.mdp_aide {
  font-style: italic;
  color: blue;
}
.mdp_valid {
  color: green;
}
</style>
