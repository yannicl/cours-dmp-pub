<template>
  <div>
    <h1>Exercice 5</h1>
    <p>Changer la couleur du texte à l'aide d'un menu dropdown.</p>
  </div>
  <select>
    <option value="red">Rouge</option>
    <option value="orange">Orange</option>
    <option value="green">Vert</option>
  </select>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</template>

<script>
export default {
}
</script>

<style scoped>
</style>
