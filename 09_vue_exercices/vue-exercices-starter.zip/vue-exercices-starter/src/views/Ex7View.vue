<template>
  <div>
    <h1>Exercice 7</h1>
    <p>Sauvegarder dans le localStorage la valeur du champs texte lorsque le bouton sauvegardé est cliqué.</p>
  </div>
  <textarea rows="5" cols="33"></textarea><br/>
  <button>Sauvegarder</button><br/>
</template>

<script>
export default {
}
</script>

<style scoped>
</style>
