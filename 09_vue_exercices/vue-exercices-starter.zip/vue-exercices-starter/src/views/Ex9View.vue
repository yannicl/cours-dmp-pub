<template>
  <div>
    <h1>Exercice 9</h1>
    <p>Ajouter un bouton dans le composant Article de l'exercice 9 pour ajouter l'article dans le panier.</p>
  </div>
  <div>
    <div>
      <h2>Mon panier</h2>
      <table>
        <thead><tr><th>Titre</th><th>Prix unitaire</th><th>Quantité</th><th>Prix</th></tr></thead>
        <tbody>
          <tr>
            <td>HP OfficeJet 8015e</td>
            <td>129.99<span>$</span></td>
            <td>1</td>
            <td>129.99<span>$</span></td>
          </tr>
        </tbody>
      </table>
      <p>Aucun article</p>
    </div>
    
  </div>
  
</template>

<script>
const articles = [
  {titre: "HP OfficeJet 8015e", prixunitaire: 129.99},
 {titre: "HP Envy Inspire 7958e", prixunitaire: 285.00, description: "Imprimante tout-en-un, impression, copie, numérisation, impression mobile et sans fil, alimentation automatique de documents."},
 {titre: "Souris sans fil HP X3000", prixunitaire: 16.99}
];
import ArticleComponent from '@/components/ArticleAvecBoutonComponent.vue';

export default {
  
}
</script>

<style scoped>
table, th, td {
  border: solid 1px black;
}
</style>
