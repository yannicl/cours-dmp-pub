<template>
    <div class="article">
    </div>
</template>

<script>
export default {
}
</script>

<style scoped>
.article {
    border: solid 1px;
    text-align: center;
    margin-bottom: 1em;
    max-width: 20em;
}
</style>
