<template>
    <div class="composant-date">
    </div>
</template>

<script>
export default {
}
</script>

<style scoped>
.composant-date {
    border: solid 1px;
    text-align: center;
}
</style>
