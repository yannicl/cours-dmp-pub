import { createRouter, createWebHistory } from 'vue-router'

import HebergementView from '../views/HebergementView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'hebergement',
      component: HebergementView
    }
  ]
});

export default router
