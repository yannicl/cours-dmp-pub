export class UserService {

    user = JSON.parse(localStorage.getItem('user') || null);
    loading = false;

    print() {
        return "User";
    }

    hasValidAccess() {
        return this.user != null && this.user.access.valid == true;
    }

    async checkin(code) {

        this.loading = true;
        let formData = new FormData();
        formData.append('code', code);

        try {
            const response = await fetch("http://localhost:3000/compte", {
                method: "POST",
                body: formData
            })
            this.user = await response.json();
            localStorage.setItem('user', JSON.stringify(this.user));
        } catch (err) {
            this.user = null;
        } finally {
            this.loading = false
        }

    }
}