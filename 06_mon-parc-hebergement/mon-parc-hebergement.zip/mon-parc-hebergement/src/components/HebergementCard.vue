<template>
    <div class="card" :class="{ disabled: this.isDisabled }">
        <img :src="this.imgSrc" class="card-img-top"
            alt="refuge">
        <div class="card-body">
            <h5 class="card-title">{{this.title}} <span class="badge text-bg-success" v-if="this.availableBeds">{{
                this.availableBeds }} places restantes</span></h5>
            <p class="card-text"><slot></slot></p>
            <a href="#" class="btn btn-primary" v-if="!this.isBooked" :class="{ disabled: this.isDisabled }" @click="this.$emit('bookedEvent')">Réserver</a>
            <a href="#" class="btn btn-danger" v-if="this.isBooked" @click="this.$emit('unbookedEvent')">Annuler votre
                réservation</a>
        </div>
    </div>
</template>
<script>
export default {
    emits: ['bookedEvent', 'unbookedEvent'],
    props : {
        id: String,
        imgSrc: String,
        isBooked: Boolean,
        isDisabled: Boolean,
        title: String,
        availableBeds: Number
    }
}
</script>
<style scoped>
.disabled img {
    filter: grayscale(0.7);
}
</style>