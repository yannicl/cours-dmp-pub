import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { UserService } from './services/UserService'

const app = createApp(App)
app.config.globalProperties.$user = new UserService();
app.provide('user', app.config.globalProperties.$user);

app.use(router)
app.mount('#app')


