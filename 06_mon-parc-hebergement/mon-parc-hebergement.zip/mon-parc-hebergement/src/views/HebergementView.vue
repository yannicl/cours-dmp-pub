<template>
    <div class="container">
        <h1>Hébergement</h1>
        <div class="alert alert-danger alert-dismissible fade show" role="alert" v-if="error">
            Erreur lors de la requête réseau. Valider votre connexion et réessayer plus tard.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="row" v-if="this.data">
            <div class="col-sm-6 col-lg-3 mb-3">
                <HebergementCard id="3" imgSrc="/cabin3.jpeg" :isBooked="(this.booked != null && this.booked == 3)" :isDisabled="(this.booked != null && this.booked != 3)" title="Le Liteau" :availableBeds="this.data.disponibilites[2]"
                    @bookedEvent="book(3)" @unbookedEvent="unbook(3)">
                    Maximun 12 personnes. Les départs doivent être effectués avant 11 h.
                </HebergementCard>
            </div>
            <div class="col-sm-6 col-lg-3 mb-3">
                <HebergementCard id="4" imgSrc="/cabin4.jpeg" :isBooked="(this.booked != null && this.booked == 4)" :isDisabled="(this.booked != null && this.booked != 4)" title="La Cache" :availableBeds="this.data.disponibilites[3]"
                    @bookedEvent="book(4)" @unbookedEvent="unbook(4)">
                    Maximun 12 personnes. Les départs doivent être effectués avant 11 h.
                </HebergementCard>
            </div>
            <div class="col-sm-6 col-lg-3 mb-3">
                <HebergementCard id="1" imgSrc="/cabin.jpeg" :isBooked="(this.booked != null && this.booked == 1)" :isDisabled="(this.booked != null && this.booked != 1)" title="La Perdière" :availableBeds="this.data.disponibilites[0]"
                    @bookedEvent="book(1)" @unbookedEvent="unbook(1)">
                    Maximun 6 personnes. Les départs doivent être effectués avant 13 h.
                </HebergementCard>
            </div>
            <div class="col-sm-6 col-lg-3 mb-3">
                <HebergementCard id="2" imgSrc="/cabin2.jpeg" :isBooked="(this.booked != null && this.booked == 2)" :isDisabled="(this.booked != null && this.booked != 2)" title="La Renardière" :availableBeds="this.data.disponibilites[1]"
                    @bookedEvent="book(2)" @unbookedEvent="unbook(2)">
                    Maximun 6 personnes. Idéal avec des enfants. Les départs doivent être effectués avant 13 h.
                </HebergementCard>
            </div>
        </div>
    </div>
</template>
<script>
import HebergementCard from "../components/HebergementCard.vue";
export default {

    components: {
        HebergementCard
    },

    data() {
        return {
            loading: true,
            data: null,
            error: null,
            booked: null
        }
    },

    computed: {
        classButton() {
            return {
                'disabled': this.booked != null,
            }
        }
    },

    methods: {
        async fetchData() {

            try {
                // replace `getPost` with your data fetching util / API wrapper
                const response = await fetch("http://localhost:3000/hebergements")
                this.data = await response.json()
            } catch (err) {
                this.error = err.toString()
            } finally {
                this.loading = false
            }
        },

        async book(id) {

            try {
                let formData = new FormData();
                formData.append('id', id);
                formData.append('nbrPersonnes', '2');

                // replace `getPost` with your data fetching util / API wrapper
                const response = await fetch("http://localhost:3000/hebergements", {
                    method: "POST",
                    body: formData
                })
                this.data = await response.json()
                this.booked = id;
            } catch (err) {
                this.error = err.toString()
            }

        },
        async unbook(id) {

            try {
                // replace `getPost` with your data fetching util / API wrapper
                const response = await fetch("http://localhost:3000/hebergements?id=" + id, {
                    method: "POST"
                })
                this.data = await response.json()
                this.booked = null;
            } catch (err) {
                this.error = err.toString()
            }

        }

    },

    mounted() {
        this.fetchData()
    },


}
</script>
<style scoped>
.disabled {
    filter: grayscale(0.7);
}
</style>